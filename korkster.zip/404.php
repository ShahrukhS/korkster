<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<title>::WalknSell::</title>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css" type="text/css">
<link rel="stylesheet" href="css/media.css" type="text/css">
<link rel="stylesheet" href="css/fontello.css" type="text/css">
<link rel="stylesheet" href="css/jquery.sidr.dark.css" type="text/css">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
<style>
*, *:before, *:after {
	-webkit-box-sizing: initial;
	-moz-box-sizing: initial;
	box-sizing: initial;
}
img {
	vertical-align: top;
}
h1.head4{font-size:70px; color:#fff; display:block; margin:141px auto 10px auto; text-align:center; font-weight:600; text-shadow:0px 4px 1px rgba(0,0,0,.2); letter-spacing:-2px;}
h2.sub-head4{font-size:50px; margin-top:59px; color:#fff; display:block; text-align:center; font-weight:600; text-shadow:0px 4px 1px rgba(0,0,0,.2); letter-spacing:-2px;}
h3.sub-sub4{font-size:40px; color:#fff; display:block; text-align:center; font-weight:600; text-shadow:0px 4px 1px rgba(0,0,0,.2); letter-spacing:-2px;}
</style>
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.sidr.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/fb.js"></script>
</head>

<body>
<article class="content">
    <div class="content_inner" style="min-height:100%;">
        <h1 class="head4">404 error</h1>
        <h2 class="sub-head4">Sorry! the page you are looking for cannot be found.</h2>    
        <h3 class="sub-sub4">Would you like to go to the <a href="index.php">homepage</a> instead?</h3>
      <!--<form method="get" action="#" id="search" name="search">
        <label for="search">Find Your School</label>
        <div id="tfheader">
          <input type="text" class="tftextinput" name="search_text" size="" id="search" placeholder="" onkeyup="findmatch();" autocomplete="off">
          <ul id="results" name="school">
          </ul>
          <input type="submit" value="Search" class="tfbutton">
          <div class="clear"></div>
        </div>
      </form>-->
    </div>
    <div class="clear"></div>
  </article>
  </body>
</html>